Tratihubis
==========

Tratihubis converts Trac tickets to Github issues by using the following steps:

1. The user manually exports the Trac tickets to convert to a CSV file.
2. Tratihubis reads the CSV file and uses the data to create Github issues and
   milestones.

For more information, visit <http://pypi.python.org/pypi/tratihubis/>.
